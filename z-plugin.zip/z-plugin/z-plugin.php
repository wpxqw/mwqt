<?php
/**
 * Plugin Name: z-plugin
 * Description: Placeholder plugin until next version of Woocommerce Quote Inquiry & Management is ready.
 */